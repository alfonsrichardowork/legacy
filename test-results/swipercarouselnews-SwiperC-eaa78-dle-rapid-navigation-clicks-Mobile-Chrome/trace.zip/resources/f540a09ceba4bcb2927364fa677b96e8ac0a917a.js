(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_6d35e5ed._.js",
  "static/chunks/app_css_styles_scss_8e830a02.css"
],
    source: "dynamic"
});
