(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_(legacy)_components_eb5ceddf._.js",
  "static/chunks/_b0471f09._.js",
  "static/chunks/node_modules_7f7cddcf._.js",
  "static/chunks/[root-of-the-server]__77c2969d._.css"
],
    source: "dynamic"
});
